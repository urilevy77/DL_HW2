import yaml
import torch
import sys
import os

# Add src to path
sys.path.insert(0, 'src')

from models.siamese_main import AttentionalSiameseNetwork

def document_experimental_setup():
    """Generate complete experimental setup documentation"""
    
    # Load config
    with open('config.yaml', 'r') as f:
        config = yaml.safe_load(f)
    
    print("="*70)
    print("EXPERIMENTAL SETUP DOCUMENTATION")
    print("="*70)
    
    # 1. Dataset Configuration
    print("\n### DATASET CONFIGURATION ###")
    print(f"Dataset: Labeled Faces in the Wild (LFW-a / deepfunneled)")
    print(f"Dataset path: {config.get('dataset_path')}")
    print(f"Train/Test split: From provided CSV files (peopleDevTrain.csv / peopleDevTest.csv)")
    print(f"Train/Validation split ratio: {config.get('train_split_ratio', 0.8)} (80% train, 20% validation)")
    print(f"Image input size: {config.get('input_shape')}")
    
    # 2. Training Hyperparameters
    print("\n### TRAINING HYPERPARAMETERS ###")
    print(f"Batch size: {config.get('batch_size')}")
    print(f"Number of epochs: {config.get('num_epochs')}")
    print(f"Learning rate: {config.get('learning_rate')}")
    print(f"Weight decay (L2 regularization): {config.get('weight_decay')}")
    print(f"Dropout probability: {config.get('dropout_prob')}")
    print(f"Optimizer: Adam (default)")
    print(f"Loss function: BCEWithLogitsLoss (Binary Cross Entropy with Logits)")
    
    # 3. Architecture Details
    print("\n### ARCHITECTURE DETAILS ###")
    print("Model: Attentional Siamese Network")
    print("\nComponent 1 - Attention Network:")
    print("  - Backbone: ResNet18 (pretrained on ImageNet)")
    print("  - Truncated: Removed AvgPool and FC layers")
    print("  - Output: [Batch, 512, 7, 7] feature maps")
    print("  - Attention conv: Conv2d(512 -> 1, kernel=1)")
    print("  - Activation: Sigmoid (outputs attention map)")
    
    print("\nComponent 2 - Feature Network:")
    print("  - Backbone: ResNet34 (pretrained on ImageNet)")
    print("  - Truncated: Removed AvgPool and FC layers")
    print("  - Output: [Batch, 512, 7, 7] feature maps")
    print("  - Dropout: Applied to feature maps")
    
    print("\nComponent 3 - Similarity Computation:")
    print("  - Distance: L2 (Euclidean) squared distance")
    print("  - Gating: Soft attention gating (element-wise multiplication)")
    print("  - Aggregation: Sum over spatial dimensions [H, W] and channels")
    print("  - Final layer: Linear(1, 1) with learnable bias")
    print("  - Output: Logits (no sigmoid, used with BCEWithLogitsLoss)")
    
    # 4. Training Strategy
    print("\n### TRAINING STRATEGY ###")
    print(f"Transfer learning: Yes (pretrained ImageNet weights)")
    print(f"Initial freezing: Backbones frozen for first {config.get('unfreeze_epoch', 5)} epochs")
    print(f"Unfreeze epoch: {config.get('unfreeze_epoch', 5)} (then fine-tune entire network)")
    print("Always trainable: attention_conv and final_layer")
    
    # 5. Stopping Criteria
    print("\n### STOPPING CRITERIA ###")
    print(f"Maximum epochs: {config.get('num_epochs')}")
    print("Early stopping: Best model saved based on validation accuracy")
    print(f"Checkpoint directory: {config.get('checkpoint_dir')}")
    print(f"TensorBoard logging: {config.get('log_dir')}")
    
    # 6. Data Augmentation
    print("\n### DATA AUGMENTATION ###")
    print("Training augmentations:")
    print("  - RandomResizedCrop(224)")
    print("  - RandomHorizontalFlip(p=0.5)")
    print("  - ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2, hue=0.1)")
    print("  - RandomRotation(10 degrees)")
    print("  - Normalization: ImageNet mean/std")
    print("\nValidation/Test augmentations:")
    print("  - Resize(256)")
    print("  - CenterCrop(224)")
    print("  - Normalization: ImageNet mean/std")
    
    # 7. Hardware & Environment
    print("\n### HARDWARE & ENVIRONMENT ###")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")
    if torch.cuda.is_available():
        print(f"GPU: {torch.cuda.get_device_name(0)}")
        print(f"CUDA version: {torch.version.cuda}")
    print(f"PyTorch version: {torch.__version__}")
    
    # 8. Reproducibility
    print("\n### REPRODUCIBILITY ###")
    print("Random seed: 42 (used in dataset splitting)")
    print("Deterministic: Should set torch.manual_seed(42) for full reproducibility")
    
    # 9. Model Parameters
    print("\n### MODEL SIZE ###")
    model = AttentionalSiameseNetwork(
        input_shape=tuple(config.get('input_shape')),
        dropout_prob=config.get('dropout_prob')
    )
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"Total parameters: {total_params:,}")
    print(f"Trainable parameters: {trainable_params:,}")
    print(f"Non-trainable parameters: {total_params - trainable_params:,}")
    
    print("\n" + "="*70)
    print("Documentation complete! Copy this output to your report.")
    print("="*70)

if __name__ == "__main__":
    document_experimental_setup()
