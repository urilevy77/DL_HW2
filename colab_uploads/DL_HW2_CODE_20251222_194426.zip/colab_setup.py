"""
Google Colab Setup Script
Run this in Colab after uploading your zip files.
"""

import os
from pathlib import Path

def setup_colab_environment():
    """
    Set up the Colab environment with data and code.
    """
    print("🚀 Setting up DL_HW2 on Google Colab...")
    print("=" * 60)
    
    # Create base directory
    base_dir = Path("/content/project")
    base_dir.mkdir(parents=True, exist_ok=True)
    
    print("\n📁 Step 1: Mounting Google Drive...")
    from google.colab import drive
    drive.mount('/content/drive')
    print("✅ Drive mounted!")
    
    # Check if data already exists
    data_exists = (base_dir / "data").exists()
    
    if not data_exists:
        print("\n📦 Step 2: Extracting DATA from Google Drive (one-time)...")
        data_zip = "/content/drive/MyDrive/DL_HW2_DATA.zip"
        
        if not Path(data_zip).exists():
            print(f"⚠️  Warning: {data_zip} not found!")
            print("Please upload DL_HW2_DATA.zip to your Google Drive root.")
            return False
        
        !unzip -q {data_zip} -d {base_dir}/
        print("✅ Data extracted!")
    else:
        print("\n✅ Step 2: Data already exists (skipping extraction)")
    
    print("\n📤 Step 3: Upload CODE zip...")
    from google.colab import files
    uploaded = files.upload()
    
    # Find the code zip
    code_zip = None
    for filename in uploaded.keys():
        if filename.startswith("DL_HW2_CODE") and filename.endswith(".zip"):
            code_zip = filename
            break
    
    if code_zip:
        print(f"\n📦 Step 4: Extracting {code_zip}...")
        !unzip -q -o {code_zip} -d {base_dir}/DL_HW2/
        print("✅ Code extracted!")
        
        # Clean up
        os.remove(code_zip)
    else:
        print("⚠️  No CODE zip found in uploaded files!")
        return False
    
    print("\n" + "=" * 60)
    print("✅ Setup complete!")
    print("=" * 60)
    print(f"\n📂 Project directory: {base_dir / 'DL_HW2'}")
    print("\nYou can now run:")
    print("  %cd /content/project/DL_HW2")
    print("  !python scripts/train.py")
    print("=" * 60)
    
    return True

# Run setup
if __name__ == "__main__":
    setup_colab_environment()
