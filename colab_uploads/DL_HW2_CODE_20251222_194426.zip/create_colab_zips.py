"""
Create separate zips for DATA (one-time) and CODE (frequent updates)
This speeds up the upload process to Google Colab significantly.
"""

import os
import zipfile
from pathlib import Path
from datetime import datetime

# Project root directory
PROJECT_ROOT = Path(__file__).parent
OUTPUT_DIR = PROJECT_ROOT / "colab_uploads"
OUTPUT_DIR.mkdir(exist_ok=True)

def create_data_zip():
    """
    Create a one-time zip of the data directory.
    This is large and only needs to be uploaded once.
    """
    print("📦 Creating DATA zip (one-time upload)...")
    data_zip_path = OUTPUT_DIR / "DL_HW2_DATA.zip"
    
    with zipfile.ZipFile(data_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        data_dir = PROJECT_ROOT / "data"
        
        if not data_dir.exists():
            print("⚠️  Warning: data directory not found!")
            return None
        
        # Add all files in data directory
        file_count = 0
        for root, dirs, files in os.walk(data_dir):
            for file in files:
                file_path = Path(root) / file
                arcname = file_path.relative_to(PROJECT_ROOT)
                zipf.write(file_path, arcname)
                file_count += 1
                if file_count % 100 == 0:
                    print(f"  Packed {file_count} files...")
        
        print(f"✅ Data zip created: {data_zip_path.name}")
        print(f"   Total files: {file_count}")
        print(f"   Size: {data_zip_path.stat().st_size / (1024*1024):.1f} MB")
        print(f"   ⚠️  Upload this file to Colab ONCE and save it in Google Drive")
    
    return data_zip_path

def create_code_zip():
    """
    Create a code-only zip (excludes data, checkpoints, logs, .git, .venv).
    This is small and can be updated frequently.
    """
    print("\n📦 Creating CODE zip (for quick updates)...")
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    code_zip_path = OUTPUT_DIR / f"DL_HW2_CODE_{timestamp}.zip"
    
    # Directories and files to EXCLUDE
    exclude_dirs = {'.git', '.venv', '__pycache__', 'data', 'checkpoints', 'logs', 
                    'results', 'colab_uploads', '.agent'}
    exclude_files = {'.gitignore', '*.pyc', '*.pyo', '*.pyd', '.DS_Store'}
    
    with zipfile.ZipFile(code_zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        file_count = 0
        
        for root, dirs, files in os.walk(PROJECT_ROOT):
            # Remove excluded directories from traversal
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                # Skip excluded files
                if file in exclude_files or file.endswith('.pyc'):
                    continue
                
                file_path = Path(root) / file
                arcname = file_path.relative_to(PROJECT_ROOT)
                
                # Skip if in colab_uploads folder
                if 'colab_uploads' in arcname.parts:
                    continue
                
                zipf.write(file_path, arcname)
                file_count += 1
        
        print(f"✅ Code zip created: {code_zip_path.name}")
        print(f"   Total files: {file_count}")
        print(f"   Size: {code_zip_path.stat().st_size / (1024):.1f} KB")
        print(f"   📤 Upload this to Colab for code updates")
    
    return code_zip_path

def main():
    print("=" * 60)
    print("🚀 DL_HW2 - Colab Upload Package Creator")
    print("=" * 60)
    
    # Ask user what to create
    print("\nOptions:")
    print("  1. Create DATA zip only (one-time, large)")
    print("  2. Create CODE zip only (frequent, small)")
    print("  3. Create BOTH")
    
    choice = input("\nEnter choice (1/2/3) [default: 2]: ").strip() or "2"
    
    print()
    
    if choice == "1":
        create_data_zip()
    elif choice == "2":
        create_code_zip()
    elif choice == "3":
        create_data_zip()
        create_code_zip()
    else:
        print("❌ Invalid choice!")
        return
    
    print("\n" + "=" * 60)
    print("📝 NEXT STEPS:")
    print("=" * 60)
    print("\n1. Upload DL_HW2_DATA.zip to your Google Drive (ONE TIME)")
    print("2. In Colab, mount Drive and extract data:")
    print("   !unzip -q /content/drive/MyDrive/DL_HW2_DATA.zip -d /content/project/")
    print("\n3. For code updates, upload DL_HW2_CODE_*.zip and extract:")
    print("   !unzip -q -o DL_HW2_CODE_*.zip -d /content/project/DL_HW2/")
    print("\n4. This way, you only upload ~50KB each time instead of several MB!")
    print("=" * 60)

if __name__ == "__main__":
    main()
